﻿using Kalikoe_BAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kalikoe.ViewModels
{
    public class BlogViewModel
    {
        public blog blogVM { get; set; }
        public List<blog> bloglistVM { get; set; }
    }
}