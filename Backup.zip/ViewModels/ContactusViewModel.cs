﻿using Kalikoe_BAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kalikoe.ViewModels
{
    public class ContactusViewModel
    {
        public contactus contactusVM { get; set; }
    }
}